'use strict'

// get question data
import QuestionData from './data.js';

// get object classes
import {Question, Option} from './classes.js';


//--------------------
// Main Quiz Object
//--------------------


let quiz = {
  qNo               : 0,
  qTot              : 0,
  Questions         : [],

  init              : function() {
                        this.qNo = 0;
                        this.Questions = [];
                        for(j=0; j<QuestionData.length; j++){
                          //this.Questions.push(new Question(j));
                          this.Questions = [...this.Questions, new Question(j)];
                        }
                        this.qTot = this.Questions.length;
                      },

  start             : function(){
                        this.init();

                        $('#intro, #scoreCard').hide();
                        $('#quiz').show();
                        $('#nextButton').html('Next Question');

                        this
                          .drawQuestion()
                          .updateProgressBar();

                        del = 75;
                      },

  drawQuestion      : function(){
                        this.Questions[this.qNo]
                          .drawOptions('optionHolder')
                          .imgIn();

                        $('#nextButton')
                          .addClass('disabled')
                          .off('click', nextQuestion);
                      },

  nextQuestion      : function(){
                        if (!this.Questions[this.qNo].lastQuestion){
                          this.Questions[this.qNo]
                            .clearOptions()
                            .imgOut();
                          this.qNo++;
                          this
                            .drawQuestion()
                            .updateProgressBar();
                        } else {
                          this.finish();
                        }
                      },

  updateProgressBar : function(){
                        $('progress').attr({
                          'value' :this.qNo + 1,
                          'max'   :this.qTot
                        });
                        $('#qNo').html(this.qNo + 1);
                        $('#qTot').html(this.qTot);
                      },

  getScore          : function(){
                        let _score = 0;
                        for (let question of this.Questions) {
                          if (question.correct){
                            _score++;
                          }
                        }
                        return parseInt((_score/this.qTot) * 100) + '%';
                      },

  finish            : function(){
                        $('#scResultHolder, #scQuestion, #scOptionHolder, #optionHolder, #question').html('');
                        $('#picHolder img').attr('src','');

                        for (let questions of this.Questions){
                          question.scDrawResult();
                        }

                        $('#scScore').html(this.getScore());
                        $('#quiz').hide();
                        $('#scoreCard').show();
                      }
}


//--------------------
// Initialisation Functions
//--------------------


let del = 0;

var nextQuestion = function(){
  quiz.nextQuestion()
}

$(document).ready(function(){
  $('#startButton, #playAgain').on('click', function(){
    quiz.start();
  });
});
